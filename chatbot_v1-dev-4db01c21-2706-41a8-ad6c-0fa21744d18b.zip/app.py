from chalice import Chalice
from chatterbot import ChatBot

app = Chalice(app_name='chatbot_api')
english_bot = ChatBot('English Bot')

@app.route('/ask', methods=['POST'])
def ask():
    request_data = app.current_request.json_body
    question = request_data['question']
    response = english_bot.get_response(question)
    return {'response': str(response)}


